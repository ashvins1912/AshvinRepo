import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

// Interface for form field configuration
interface FormFieldConfig {
  type: 'text' | 'radio' | 'multiselect' | 'calendar';
  label: string;
  name: string;
  value?: any;
  options?: { value: any; label: string }[];
  validators?: any[];
  styles?: { [key: string]: string };
}

// Interface for button configuration
interface ButtonConfig {
  label: string;
  callback: () => void;
  styles?: { [key: string]: string };
}

// Abstract factory interface
interface FormFieldFactory {
  createField(config: FormFieldConfig): FormFieldConfig;
}

// Concrete factories for each field type
class TextFieldFactory implements FormFieldFactory {
  createField(config: FormFieldConfig): FormFieldConfig {
    return {
      ...config,
      type: 'text',
      validators: config.validators || [Validators.required],
      styles: config.styles || {
        'width': '100%',
        'margin-bottom': '15px',
        'padding': '8px'
      }
    };
  }
}

class RadioFieldFactory implements FormFieldFactory {
  createField(config: FormFieldConfig): FormFieldConfig {
    return {
      ...config,
      type: 'radio',
      validators: config.validators || [Validators.required],
      styles: config.styles || {
        'display': 'flex',
        'flex-direction': 'column',
        'margin-bottom': '15px'
      }
    };
  }
}

class MultiSelectFieldFactory implements FormFieldFactory {
  createField(config: FormFieldConfig): FormFieldConfig {
    return {
      ...config,
      type: 'multiselect',
      validators: config.validators || [Validators.required],
      styles: config.styles || {
        'width': '100%',
        'margin-bottom': '15px'
      }
    };
  }
}

class CalendarFieldFactory implements FormFieldFactory {
  createField(config: FormFieldConfig): FormFieldConfig {
    return {
      ...config,
      type: 'calendar',
      validators: config.validators || [Validators.required],
      styles: config.styles || {
        'width': '100%',
        'margin-bottom': '15px'
      }
    };
  }
}

// Factory creator
class FormFieldFactoryCreator {
  static getFactory(type: string): FormFieldFactory {
    switch (type) {
      case 'text':
        return new TextFieldFactory();
      case 'radio':
        return new RadioFieldFactory();
      case 'multiselect':
        return new MultiSelectFieldFactory();
      case 'calendar':
        return new CalendarFieldFactory();
      default:
        throw new Error('Invalid field type');
    }
  }
}

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss']
})
export class DynamicFormComponent implements OnInit {
  dynamicForm!: FormGroup;
  formFields: FormFieldConfig[] = [];
  buttons: ButtonConfig[] = [];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.initializeForm();
  }

  initializeForm(): void {
    // Create form fields using factory pattern
    const textField = FormFieldFactoryCreator.getFactory('text').createField({
      label: 'Username',
      name: 'username',
      validators: [Validators.required, Validators.minLength(3)],
      styles: {
        'border': '1px solid #3f51b5',
        'border-radius': '4px'
      }
    });

    const radioField = FormFieldFactoryCreator.getFactory('radio').createField({
      label: 'Gender',
      name: 'gender',
      options: [
        { value: 'male', label: 'Male' },
        { value: 'female', label: 'Female' }
      ],
      styles: {
        'gap': '10px'
      }
    });

    const multiSelectField = FormFieldFactoryCreator.getFactory('multiselect').createField({
      label: 'Interests',
      name: 'interests',
      options: [
        { value: 'coding', label: 'Coding' },
        { value: 'reading', label: 'Reading' },
        { value: 'sports', label: 'Sports' }
      ],
      styles: {
        'border': '1px solid #3f51b5'
      }
    });

    const calendarField = FormFieldFactoryCreator.getFactory('calendar').createField({
      label: 'Date of Birth',
      name: 'dob',
      styles: {
        'border': '1px solid #3f51b5'
      }
    });

    this.formFields = [textField, radioField, multiSelectField, calendarField];

    // Initialize form group
    const formGroup: { [key: string]: any } = {};
    this.formFields.forEach(field => {
      formGroup[field.name] = [field.value || '', field.validators || []];
    });

    this.dynamicForm = this.fb.group(formGroup);

    // Initialize buttons
    this.buttons = [
      {
        label: 'Submit',
        callback: this.submitForm.bind(this),
        styles: {
          'background-color': '#3f51b5',
          'color': 'white',
          'padding': '10px 20px',
          'border-radius': '4px'
        }
      },
      {
        label: 'Reset',
        callback: this.resetForm.bind(this),
        styles: {
          'background-color': '#f44336',
          'color': 'white',
          'padding': '10px 20px',
          'border-radius': '4px'
        }
      }
    ];
  }

  submitForm(): void {
    if (this.dynamicForm.valid) {
      console.log('Form Submitted:', this.dynamicForm.value);
      // Add your submit logic here
    } else {
      console.log('Form is invalid');
    }
  }

  resetForm(): void {
    this.dynamicForm.reset();
    console.log('Form Reset');
  }

  getErrorMessage(fieldName: string): string {
    const control = this.dynamicForm.get(fieldName);
    if (control?.hasError('required')) {
      return 'This field is required';
    }
    if (control?.hasError('minlength')) {
      return 'Minimum length is 3 characters';
    }
    return '';
  }

  getStyles(styles: { [key: string]: string } | undefined): string {
    if (!styles) return '';
    return Object.entries(styles)
      .map(([key, value]) => `${key}: ${value}`)
      .join('; ');
  }
}